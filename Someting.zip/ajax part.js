// This is in jQuery
$('.comment-ajax').on('submit', function(event){
    event.preventDefault();
    post = $(this).parents().eq(3); // Target the post
    post.find('.comment-holder').click(); // Hide the form
    post.find('.comment-deleted-txt').slideUp(); // Hide deleted text if present
    // Math on the number of comments
    nofCmt = post.find('.view-comment-link span').html();
    if (nofCmt == " ") {
        newTotal = 2;
    } else {
        newTotal = parseInt(nofCmt) + 1;
    }
    if (newTotal == 1) {
        post.find('.view-comment-link span').html(' ');
    } else {
        post.find('.view-comment-link span').html(' ' + newTotal + '');
    }
    // Math ends
    post.find('.view-comment-link').slideDown(); // Show 'View all comments'
    post.find('.comment-added-txt').slideDown(); // Show 'Comment added' text
    $.ajax({
        type: 'POST',
        url: $(this).attr('action'), 
        data: $(this).serialize(),
        success: function(){ // Perform a task after getting 200 response code
        },
        error: function(rs, e) {
            alert('Connection lost.  ' + rs.responseText) // error fallback
        }
    })
});

$('.sure-delete-cmt-ajax').on('submit', function(event){
    event.preventDefault();
    formTag = this;
    post = $(this).parents().eq(6); // Target the post
    post.find('.comment-added-txt').slideUp() // Hide comment added text if present
    nofCmt = post.find('.view-comment-link span').html()
    newTotal = parseInt(nofCmt) - 1; // Decrement no. of comments
    post.find('.view-comment-link span').html(' ' + newTotal + '')
    post.find('.comment-deleted-txt').slideDown() // Show comment deleted text
    $(formTag).parents().eq(3).slideUp() // Comment

    $.ajax({
        type: 'POST',
        url: $(this).attr('action'),
        data: { csrfmiddlewaretoken: '{{ csrf_token }}' },
        success: function(){ // Success function (It's optional BTW)
        },
        error: function(rs, e) {
            alert('Connection lost.  ' + rs.responseText)
        }
    })
});